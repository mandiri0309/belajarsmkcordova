<?php

/* cetak-info-login-siswa.html */
class __TwigTemplate_3bcf7b24ff21d0c283ce5a42e6306b78eb84e2e5c4807719cddffc8e8bece47b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-print.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-print.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Cetak informasi login siswa - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<table width=\"100%\" cellpadding=\"5\">
    <tr>
    ";
        // line 10
        $context["col"] = 3;
        // line 11
        echo "    ";
        $context["l"] = 0;
        // line 12
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["siswas"]) ? $context["siswas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            // line 13
            echo "        ";
            if (((isset($context["l"]) ? $context["l"] : null) >= (isset($context["col"]) ? $context["col"] : null))) {
                // line 14
                echo "            </tr><tr>
            ";
                // line 15
                $context["l"] = 0;
                // line 16
                echo "        ";
            }
            // line 17
            echo "        ";
            $context["l"] = ((isset($context["l"]) ? $context["l"] : null) + 1);
            // line 18
            echo "
        <td>
            <div style=\"border:1px solid gray;padding-bottom:5px;\">
                <p><center><b>Informasi Login E-learning</b></center></p>
                <table class=\"table table-condensed table-striped\" style=\"margin-bottom: 5px;\">
                    <tr>
                        <td style=\"width:70px;\">NIS</td>
                        <td>: ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "nis"), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td valign=\"top\">Nama</td>
                        <td>: ";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "nama"), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td valign=\"top\">: ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "login"), "username"), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td valign=\"top\">: ";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "login"), "password"), "html", null, true);
            echo "</td>
                    </tr>
                </table>
                <center>";
            // line 40
            echo twig_escape_filter($this->env, base_url(), "html", null, true);
            echo "</center>
            </div>
        </td>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "    </tr>
</table>
";
    }

    public function getTemplateName()
    {
        return "cetak-info-login-siswa.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 44,  106 => 40,  100 => 37,  93 => 33,  86 => 29,  79 => 25,  70 => 18,  67 => 17,  64 => 16,  62 => 15,  59 => 14,  56 => 13,  51 => 12,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
