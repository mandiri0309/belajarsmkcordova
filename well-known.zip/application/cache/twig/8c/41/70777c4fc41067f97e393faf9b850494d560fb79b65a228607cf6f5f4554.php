<?php

/* pantau-ujian.html */
class __TwigTemplate_8c4170777c4fc41067f97e393faf9b850494d560fb79b65a228607cf6f5f4554 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Pantau Ujian - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("tugas", "Tugas");
        echo " / ";
        echo anchor(((("tugas/" . ((($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 2)) ? ("koreksi") : ("nilai"))) . "/") . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")), "Lihat Nilai");
        echo " / Pantau Ujian</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("tugas");
        echo "

        <div class=\"bs-callout bs-callout-info\">
            <div class=\"btn-group pull-right\" style=\"margin-top:-5px;\">
                ";
        // line 17
        echo anchor(((("plugins/custom_tugas/edit/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon icon-edit\"></i> Edit Tugas", array("class" => "btn btn-default"));
        echo "
                ";
        // line 18
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 0)) {
            // line 19
            echo "                    ";
            echo anchor(((("tugas/terbitkan/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-ok\"></i> Terbitkan", array("class" => "btn btn-success btn-small"));
            echo "
                ";
        } elseif (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 1)) {
            // line 21
            echo "                    ";
            echo anchor(((("tugas/tutup/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-minus\"></i> Tutup", array("class" => "btn btn-danger btn-small"));
            echo "
                ";
        }
        // line 23
        echo "            </div>

            ";
        // line 25
        $this->env->loadTemplate("info-tugas.html")->display($context);
        // line 26
        echo "
        </div>
        <br>

        <table class=\"table table-striped datatable\">
            <thead>
                <tr>
                    <th>Siswa</th>
                    <th width=\"60%\">Informasi</th>
                </tr>
            </thead>
            <tbody>
                ";
        // line 38
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["retrieve_all"]) ? $context["retrieve_all"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["n"]) {
            // line 39
            echo "                <tr>
                    <td>
                        <img style=\"height:20px;width:20px; margin-right: 10px;\" class=\"img-polaroid img-circle pull-left\" src=\"";
            // line 41
            echo twig_escape_filter($this->env, get_url_image_siswa($this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "foto"), "medium", $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "jenis_kelamin")), "html", null, true);
            echo "\">
                        <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, site_url(((("siswa/detail/" . $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "status_id")) . "/") . $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "id"))), "html", null, true);
            echo "\"><b>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "nama"), "html", null, true);
            echo " ";
            echo (((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "nis")))) ? ((("<span class=\"text-muted\">(" . $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "nis")) . ")</span>")) : (""));
            echo "</b></a>
                        <br> ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "kelas_aktif"), "nama"), "html", null, true);
            echo " <span class=\"text-muted\">(";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "kelas_aktif"), "id"), "html", null, true);
            echo ")</span>
                    </td>
                    <td>
                        <table class=\"table table-condensed table-bordered\">
                            <tr>
                                <td width=\"20%\">IP</td>
                                <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["n"]) ? $context["n"] : null), "ip"), "html", null, true);
            echo "</td>
                            </tr>
                            <tr>
                                <td>Agent</td>
                                <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["n"]) ? $context["n"] : null), "agent_string"), "html", null, true);
            echo "</td>
                            </tr>
                            <tr>
                                <td>Mulai</td>
                                <td>";
            // line 57
            echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "mulai")), "html", null, true);
            echo "</td>
                            </tr>
                            <tr>
                                <td>Selesai</td>
                                <td>";
            // line 61
            echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "selesai")), "html", null, true);
            echo "</td>
                            </tr>
                            <tr>
                                <td>Sisa waktu</td>
                                <td>";
            // line 65
            echo $this->getAttribute((isset($context["n"]) ? $context["n"] : null), "sisa_menit_string");
            echo "</td>
                            </tr>
                            <tr>
                                <td colspan=\"2\">
                                    <div class=\"btn-group\">
                                        ";
            // line 70
            echo anchor(((("tugas/pantau/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/jawaban_sementara/") . $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "id")), "Lihat jawaban sementara", array("class" => "btn btn-small btn-primary iframe-jawaban-sementara"));
            echo "
                                        <a href=\"";
            // line 71
            echo twig_escape_filter($this->env, site_url(((("tugas/pantau/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/reset/") . $this->getAttribute($this->getAttribute((isset($context["n"]) ? $context["n"] : null), "siswa"), "id"))), "html", null, true);
            echo "\" class=\"btn btn-small btn-default\" onclick=\"return confirm('Anda yakin ingin mengulang proses ujian siswa tersebut?')\" data-toggle=\"tooltip\" title=\"Ulang proses ujian siswa<br>dan anggap belum mengerjakan.\">Reset</a>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['n'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "            </tbody>
        </table>

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "pantau-ujian.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 79,  170 => 71,  166 => 70,  158 => 65,  151 => 61,  144 => 57,  137 => 53,  130 => 49,  119 => 43,  111 => 42,  107 => 41,  103 => 39,  99 => 38,  85 => 26,  83 => 25,  79 => 23,  73 => 21,  67 => 19,  65 => 18,  61 => 17,  54 => 13,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
