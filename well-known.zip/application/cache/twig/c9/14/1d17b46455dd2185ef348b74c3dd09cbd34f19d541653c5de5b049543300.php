<?php

/* layout-private.html */
class __TwigTemplate_c9141d17b46455dd2185ef348b74c3dd09cbd34f19d541653c5de5b049543300 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->env->loadTemplate("layout-header.html")->display($context);
        // line 6
        echo "        ";
        $this->displayBlock('css', $context, $blocks);
        // line 7
        echo "    </head>
    
    

    <body>
        <div class=\"navbar navbar-fixed-top\">
            <div class=\"navbar-inner\">
                <div class=\"container\">
                    <a class=\"btn btn-navbar\" data-toggle=\"collapse\" data-target=\".navbar-inverse-collapse\">
                        <i class=\"icon-reorder shaded\"></i>
                    </a>
                    <a class=\"brand\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["site_url"]) ? $context["site_url"] : null), "html", null, true);
        echo "\">
                        <img src=\"";
        // line 19
        echo twig_escape_filter($this->env, get_logo_config(), "html", null, true);
        echo "\"> <span class=\"visible-phone brand-txt\">Belajar Online</span><span class=\"visible-desktop visible-tablet brand-txt\">";
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
        echo "</span>
                    </a>
                    <div class=\"nav-collapse collapse navbar-inverse-collapse\">
                        <form class=\"navbar-search pull-left input-append\" method=\"get\" action=\"";
        // line 22
        echo twig_escape_filter($this->env, site_url("welcome/search"), "html", null, true);
        echo "\">
                            <input type=\"text\" class=\"span3\" name=\"q\">
                            <button class=\"btn\" type=\"submit\">
                                <i class=\"icon-search\"></i>
                            </button>
                        </form>
                        <ul class=\"nav pull-right\">
                            ";
        // line 29
        $this->env->loadTemplate("top-mobile-menu.html")->display($context);
        // line 30
        echo "
                            ";
        // line 31
        if (is_admin()) {
            // line 32
            echo "                          
                            ";
        }
        // line 34
        echo "                            <li class=\"nav-user dropdown\"><a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                                ";
        // line 35
        echo twig_escape_filter($this->env, nama_panggilan(get_sess_data("user", "nama")), "html", null, true);
        echo "

                                <span class=\"pull-right\">
                                <img src=\"";
        // line 38
        echo twig_escape_filter($this->env, get_url_image_session(get_sess_data("user", "foto"), "medium", get_sess_data("user", "jenis_kelamin")), "html", null, true);
        echo "\" class=\"nav-avatar img-polaroid\" />
                                <b class=\"caret\"></b></a>
                                </span>
                                <ul class=\"dropdown-menu\">
                                    ";
        // line 42
        if (is_admin()) {
            // line 43
            echo "                                    <li>";
            echo anchor(((("pengajar/detail/" . get_sess_data("user", "status_id")) . "/") . get_sess_data("user", "id")), "Detail Profil", array("title" => "Detail Profil"));
            echo "</li>
                                    ";
        }
        // line 45
        echo "
                                    ";
        // line 46
        if (is_pengajar()) {
            // line 47
            echo "                                    <li>";
            echo anchor("login/pp", "Profil & Akun Login");
            echo "</li>
                                    ";
        }
        // line 49
        echo "
                                    ";
        // line 50
        if (is_siswa()) {
            // line 51
            echo "                                    <!--<li>";
            echo anchor("login/pp", "Profil & Akun Login");
            echo "</li>-->
                                    ";
        }
        // line 53
        echo "
                                    <li><a href=\"";
        // line 54
        echo twig_escape_filter($this->env, site_url(("login/login_log/" . get_sess_data("login", "id"))), "html", null, true);
        echo "\">Login log</a></li>
                                    <li><a href=\"";
        // line 55
        echo twig_escape_filter($this->env, site_url("login/logout"), "html", null, true);
        echo "\">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>

        <!-- /navbar -->
        <div class=\"wrapper\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"span3 visible-desktop\">
                        <div class=\"sidebar\">
                            ";
        // line 72
        $this->env->loadTemplate("sidebar-menu.html")->display($context);
        // line 73
        echo "                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->
                    <div class=\"span9 mobile-12\">
                      <div class=\"content\">
                            ";
        // line 79
        if ((pass_siswa_equal_nis() == true)) {
            // line 80
            echo "                                ";
            echo get_alert("warning", ("DIMOHON MENAATI PERATURAN" . (isset($context["anchor"]) ? $context["anchor"] : null)));
            echo "
                            ";
        }
        // line 82
        echo "
                            ";
        // line 83
        $this->displayBlock('content', $context, $blocks);
        // line 84
        echo "                        </div> 
                    </div> 
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class=\"footer\">
            <div class=\"container\">
                <center>
                    <b class=\"copyright\">";
        // line 95
        echo (isset($context["copyright"]) ? $context["copyright"] : null);
        echo " </b>
                   
                </center>
            </div>
        </div>
        
        
   <!-- Histats.com  START  (aync)-->
<script type=\"text/javascript\">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4410077,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href=\"/\" target=\"_blank\"><img  src=\"//sstatic1.histats.com/0.gif?4410077&101\" alt=\"\" border=\"0\"></a></noscript>
<!-- Histats.com  END  -->
        


        ";
        // line 117
        $this->env->loadTemplate("layout-footer.html")->display($context);
        // line 118
        echo "        ";
        $this->displayBlock('js', $context, $blocks);
        // line 119
        echo "
    </body>
</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
    }

    // line 6
    public function block_css($context, array $blocks = array())
    {
    }

    // line 83
    public function block_content($context, array $blocks = array())
    {
    }

    // line 118
    public function block_js($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout-private.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 118,  240 => 83,  235 => 6,  229 => 4,  222 => 119,  219 => 118,  217 => 117,  192 => 95,  179 => 84,  177 => 83,  174 => 82,  168 => 80,  166 => 79,  158 => 73,  156 => 72,  136 => 55,  132 => 54,  129 => 53,  123 => 51,  121 => 50,  118 => 49,  112 => 47,  110 => 46,  107 => 45,  101 => 43,  99 => 42,  92 => 38,  86 => 35,  83 => 34,  79 => 32,  77 => 31,  74 => 30,  72 => 29,  62 => 22,  54 => 19,  50 => 18,  37 => 7,  34 => 6,  32 => 5,  28 => 4,  23 => 1,);
    }
}
