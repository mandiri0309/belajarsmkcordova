<?php

/* covid.html */
class __TwigTemplate_d25b2b3f273fa8411f62421cdf5f1c6fa77fa041f90fabfb667f0023a2db6fab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-public.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-public.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Covid-19 - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "      
    <div class=\"container\">
            <center><p class=\"text-muted\"><b>EDUKASI COVID-19</b></p></center>
           
           
            
            <script type=\"text/javascript\">
            // cek diakses dengan iframe atau tidak
            function inIframe()
            {
                var is_iframe = true;
                try {
                    is_iframe = window.self !== window.top;
                } catch (e) {
                    is_iframe = true;
                }

                if (!is_iframe) {
                    \$(\"#body-content\").html('redirect...');
                    window.location.replace(https://www.youtube.com/embed/ciRwAED2mVs);
                }
            }
        </script>
           
             
    </div>
           
      
";
    }

    public function getTemplateName()
    {
        return "covid.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
