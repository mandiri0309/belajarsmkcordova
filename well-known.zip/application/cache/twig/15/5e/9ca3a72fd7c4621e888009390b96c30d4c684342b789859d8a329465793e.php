<?php

/* manajemen-tugas.html */
class __TwigTemplate_155e9ca3a72fd7c4621e888009390b96c30d4c684342b789859d8a329465793e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Manajemen Soal Tugas - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_css($context, array $blocks = array())
    {
        // line 8
        echo "<style type=\"text/css\">
    .box-area-pertanyaan {
        padding: 15px;
        background-color: #F6F6F6;
        border-radius: 3px;
    }
    .box-pilihan {
        padding: 5px 0px 15px 30px;
        border-radius: 3px;
    }
</style>
";
    }

    // line 21
    public function block_content($context, array $blocks = array())
    {
        // line 22
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 24
        echo anchor("tugas", "Tugas");
        echo " / Manajemen Soal Tugas</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 27
        echo get_flashdata("tugas");
        echo "

        <div class=\"bs-callout bs-callout-info\">
            <div class=\"btn-group pull-right\" style=\"margin-top:-5px;\">
                ";
        // line 31
        echo anchor(((("plugins/custom_tugas/edit/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon icon-edit\"></i> Edit Tugas", array("class" => "btn btn-default"));
        echo "
                ";
        // line 32
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 0)) {
            // line 33
            echo "                    ";
            echo anchor(((("tugas/terbitkan/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-ok\"></i> Terbitkan", array("class" => "btn btn-success btn-small"));
            echo "
                ";
        } elseif (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 1)) {
            // line 35
            echo "                    ";
            echo anchor(((("tugas/tutup/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-minus\"></i> Tutup", array("class" => "btn btn-danger btn-small"));
            echo "
                ";
        }
        // line 37
        echo "            </div>

            ";
        // line 39
        $this->env->loadTemplate("info-tugas.html")->display($context);
        // line 40
        echo "
        </div>
        <br>

        <div class=\"dropdown pull-right\">
            <a class=\"dropdown-toggle btn btn-default\" id=\"drop4\" role=\"button\" data-toggle=\"dropdown\" href=\"#\">Berikutnya <b class=\"caret\"></b></a>
            <ul id=\"menu1\" class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"drop4\">
                <li role=\"presentation\"><a role=\"menuitem\" tabindex=\"-1\" href=\"";
        // line 47
        echo twig_escape_filter($this->env, site_url("plugins/bank_soal"), "html", null, true);
        echo "\">Kelola bank soal</a></li>
            </ul>
        </div>
        <div class=\"btn-group\">
            <a href=\"javascript:void(0)\" class=\"btn btn-primary disable-on-add-pertanyaan ";
        // line 51
        echo ((($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 3)) ? ("btn-tambah-pertanyaan") : ("btn-tambah-pertanyaan-essay"));
        echo "\" title=\"Tambah Pertanyaan\">Tambah Pertanyaan</a>
            <a href=\"";
        // line 52
        echo twig_escape_filter($this->env, site_url(("tugas/copy_soal/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id"))), "html", null, true);
        echo "\" class=\"disable-on-add-pertanyaan btn btn-primary iframe-copy-pertanyaan\" title=\"Copy Pertanyaan\">Copy Soal Tugas</a>
            <a href=\"";
        // line 53
        echo twig_escape_filter($this->env, site_url(("plugins/bank_soal/copy_soal_bank/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id"))), "html", null, true);
        echo "\" class=\"disable-on-add-pertanyaan btn btn-primary iframe-bank-soal iframe-copy-pertanyaan\" title=\"Bank Soal\">Copy Bank Soal</a>
            <a href=\"";
        // line 54
        echo twig_escape_filter($this->env, site_url(("plugins/bank_soal/import_excel_soal_tugas/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id"))), "html", null, true);
        echo "\" class=\"disable-on-add-pertanyaan btn btn-primary\" title=\"Import Excel\">Import Excel</a>
        </div>
        <br><br>

        ";
        // line 58
        echo form_open(("plugins/bank_soal/add_soal/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")), array("id" => "form-tambah-pertanyaan"));
        echo "
            <div class=\"box-new-soal\"></div>
        ";
        // line 60
        echo form_close();
        echo "

        <table class=\"table\">
            <thead>
                <tr>
                    <th width=\"5%\">No</th>
                    <th>Pertanyaan ";
        // line 66
        echo ((($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 3)) ? (" dan Pilihan") : (""));
        echo "</th>
                </tr>
            </thead>
            <tbody>
                ";
        // line 70
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pertanyaan"]) ? $context["pertanyaan"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 71
            echo "                <tr id=\"pertanyaan-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                    <td><b>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "urutan"), "html", null, true);
            echo ".</b></td>
                    <td>
                        <div class=\"pertanyaan\">
                            <div class=\"btn-group pull-right\" style=\"margin-left:10px;\">
                                <a href=\"";
            // line 76
            echo twig_escape_filter($this->env, site_url(((((("plugins/bank_soal/edit_soal/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id")) . "/") . enurl_redirect(current_url()))), "html", null, true);
            echo "\" class=\"btn btn-small btn-default\"><i class=\"icon-edit\"></i> Edit</a>
                                <a onclick=\"return confirm('Anda yakin ingin menghapus?')\" href=\"";
            // line 77
            echo twig_escape_filter($this->env, site_url(((((("tugas/hapus_soal/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id")) . "/") . enurl_redirect(current_url()))), "html", null, true);
            echo "\" class=\"btn btn-small btn-default\"><i class=\"icon-trash\"></i> Hapus</a>
                            </div>

                            ";
            // line 80
            echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
            echo "
                        </div>

                        ";
            // line 83
            if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 3)) {
                // line 84
                echo "                        <br>
                        <div id=\"pilihan-";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                            <table class=\"table table-condensed\">
                                <tbody>
                                    ";
                // line 88
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
                foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                    if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                        // line 89
                        echo "                                    <tr ";
                        echo ((($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) ? ("style=\"background-color: #fbfbfb;margin-left: 10px;\"") : (""));
                        echo ">
                                        <td width=\"3%\"><b>(";
                        // line 90
                        echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan")), "html", null, true);
                        echo ")</b></td>
                                        <td>
                                            ";
                        // line 92
                        if (($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) {
                            // line 93
                            echo "                                            <span class=\"text-success pull-right\"><i class=\"icon-ok\"></i> Kunci Jawaban</span>
                                            ";
                        }
                        // line 95
                        echo "                                            ";
                        echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                        echo "
                                        </td>
                                    </tr>
                                    ";
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 99
                echo "                                </tbody>
                            </table>
                        </div>
                        ";
            }
            // line 103
            echo "
                    </td>
                </tr>

                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "            </tbody>
        </table>
        <br>
        ";
        // line 111
        echo (isset($context["pagination"]) ? $context["pagination"] : null);
        echo "

    </div>
</div>
";
    }

    // line 117
    public function block_js($context, array $blocks = array())
    {
        // line 118
        echo get_texteditor();
        echo "
<script type=\"text/javascript\" src=\"";
        // line 119
        echo twig_escape_filter($this->env, base_url_plugins("src/bank_soal/js/pertanyaan.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "manajemen-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  272 => 119,  268 => 118,  265 => 117,  256 => 111,  251 => 108,  241 => 103,  235 => 99,  223 => 95,  219 => 93,  217 => 92,  212 => 90,  207 => 89,  202 => 88,  196 => 85,  193 => 84,  191 => 83,  185 => 80,  179 => 77,  175 => 76,  168 => 72,  163 => 71,  159 => 70,  152 => 66,  143 => 60,  138 => 58,  131 => 54,  127 => 53,  123 => 52,  119 => 51,  112 => 47,  103 => 40,  101 => 39,  97 => 37,  91 => 35,  85 => 33,  83 => 32,  79 => 31,  72 => 27,  66 => 24,  62 => 22,  59 => 21,  44 => 8,  41 => 7,  34 => 4,  31 => 3,);
    }
}
