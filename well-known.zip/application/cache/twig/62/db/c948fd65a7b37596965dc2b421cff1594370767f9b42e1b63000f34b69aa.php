<?php

/* help.html */
class __TwigTemplate_62dbc948fd65a7b37596965dc2b421cff1594370767f9b42e1b63000f34b69aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-public.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-public.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Help - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "      
    <div class=\"container\">
            
            <div class=\"btn-box-row row-fluid\">
                <center><p class=\"text-muted\"><b>HANYA MELAYANI PADA JAM KERJA = 07.00-15.00 WIB</b></p></center>
            </div>
            <div class=\"btn-box-row row-fluid\">
                <a href=\"https://s.id/fayMp\" class=\"btn-box big span3\">
                    <i class=\"icon-user\"></i><b>Help Desk 1</b>
                    <p class=\"text-muted\">Bagian Kurikulum</p>
                </a>
                <a href=\"https://s.id/faz9G\" class=\"btn-box big span3\">
                    <i class=\"icon-user\"></i><b>Help Desk 2</b>
                    <p class=\"text-muted\">Bagian Multimedia</p>
                </a>
                <a href=\"https://s.id/fsYcH\" class=\"btn-box big span3\">
                    <i class=\"icon-user\"></i><b>Help Desk 3</b>
                    <p class=\"text-muted\">Bagian Farmasi</p>
                </a>
                <a href=\"https://s.id/fazMc\" class=\"btn-box big span3\">
                    <i class=\"icon-user\"></i><b>Help Desk 4</b>
                    <p class=\"text-muted\">Bagian TBSM & KI</p>
                </a>
                <a href=\"https://s.id/faz9G\" class=\"btn-box big span3\">
                    <i class=\"icon-user\"></i><b>Help Desk 4</b>
                    <p class=\"text-muted\">Bagian Teknik Aplikasi</p>
                </a>
            </div>
            
            
                
    </div>
           
      
";
    }

    public function getTemplateName()
    {
        return "help.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
