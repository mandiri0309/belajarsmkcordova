<?php

/* screening.html */
class __TwigTemplate_7be39f652d751210ee8a013a2b85d62c9e0d056307478c2ab8c5a289d0b459d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-public.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-public.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Screening Covid-19 - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "      
    <div class=\"container\">
            
            <div class=\"btn-box-row row-fluid\">
                
            <center><p class=\"text-muted\"><b>SITUS BELAJAR ONLINE SMK CORDOVA TANGGAP COVID-19 BEKERJASAMA DENGAN DISKOMINFO PATI</b></p></center>
            
            
            </div>
            
            <script type=\"text/javascript\">
            // cek diakses dengan iframe atau tidak
            function inIframe()
            {
                var is_iframe = true;
                try {
                    is_iframe = window.self !== window.top;
                } catch (e) {
                    is_iframe = true;
                }

                if (!is_iframe) {
                    \$(\"#body-content\").html('redirect...');
                    window.location.replace(https://corona.jatengprov.go.id/screening);
                }
            }
        </script>
           
             
    </div>
           
      
";
    }

    public function getTemplateName()
    {
        return "screening.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
