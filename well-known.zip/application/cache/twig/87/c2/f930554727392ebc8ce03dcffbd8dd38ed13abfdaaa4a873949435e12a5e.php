<?php

/* sidebar-menu.html */
class __TwigTemplate_87c2f930554727392ebc8ce03dcffbd8dd38ed13abfdaaa4a873949435e12a5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
";
        // line 2
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["list_menu"]) ? $context["list_menu"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["menus"]) {
            // line 3
            echo "    <ul class=\"widget widget-menu unstyled\">
    ";
            // line 4
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["menus"]) ? $context["menus"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                // line 5
                echo "        <li>";
                echo (isset($context["menu"]) ? $context["menu"] : null);
                echo "</li>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 7
            echo "    </ul>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menus'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "sidebar-menu.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 5,  31 => 4,  26 => 3,  22 => 2,  19 => 1,  240 => 113,  235 => 81,  230 => 6,  224 => 4,  217 => 114,  212 => 112,  190 => 93,  177 => 82,  175 => 81,  172 => 80,  166 => 78,  156 => 71,  134 => 53,  130 => 52,  127 => 51,  121 => 49,  119 => 48,  116 => 47,  110 => 45,  108 => 44,  105 => 43,  99 => 41,  97 => 40,  84 => 33,  75 => 29,  72 => 28,  70 => 27,  60 => 20,  48 => 16,  37 => 7,  34 => 6,  28 => 4,  23 => 1,  214 => 113,  209 => 75,  200 => 68,  189 => 63,  185 => 62,  179 => 59,  173 => 58,  164 => 77,  160 => 55,  154 => 70,  150 => 50,  146 => 49,  131 => 37,  111 => 33,  94 => 32,  90 => 36,  83 => 26,  81 => 32,  77 => 30,  71 => 21,  65 => 19,  63 => 18,  59 => 17,  52 => 17,  46 => 10,  42 => 7,  39 => 7,  32 => 5,  29 => 4,);
    }
}
