<?php

/* list-jurnal.html */
class __TwigTemplate_24dd8e9a03294e1961c285ccdea7fe1f9050fa5f725ae8b99b032d9871656d79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Jurnal - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>Jurnal</h3>
    </div>
    <div class=\"module-body\">
        

        <div class=\"clearfix\">
            <div class=\"pull-right\">
             <B>#DiRumahAja</B>
            </div>
            <div class=\"pull-left\">
                <b>#SemogaSehatSelalu</b>
            </div>
        </div>
        <br>

        <div class=\"table-responsive\">
            <iframe width=\"100%\" height=\"1650px\" src=\"https://docs.google.com/forms/d/e/1FAIpQLSc5K9CobWj8KjsxPvIdbFZ6KZ-ZLnF1hqaXGNg22i9_KJrK1w/viewform\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
        </div>
                   <script type=\"text/javascript\">
            // cek diakses dengan iframe atau tidak
            function inIframe()
            {
                var is_iframe = true;
                try {
                    is_iframe = window.self !== window.top;
                } catch (e) {
                    is_iframe = true;
                }

                if (!is_iframe) {
                    \$(\"#body-content\").html('redirect...');
                    window.location.replace(https://s.id/fCy08);
                }
            }
        </script>

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "list-jurnal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
