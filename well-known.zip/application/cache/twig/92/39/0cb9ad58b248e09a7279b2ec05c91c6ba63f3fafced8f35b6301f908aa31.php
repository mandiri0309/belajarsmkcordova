<?php

/* ujian-online.html */
class __TwigTemplate_92390cb9ad58b248e09a7279b2ec05c91c6ba63f3fafced8f35b6301f908aa31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-ujian.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-ujian.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "judul"), "html", null, true);
        echo " - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_css($context, array $blocks = array())
    {
        // line 8
        echo "<style type=\"text/css\">
    .no-list {
        padding-left: 0px;
        list-style: outside none none;
        margin-top: 20px;
        margin-right: 12px;
    }
    .no-list li {
        width: 12.5%;
        font-size: 12px;
    }
    .no-list li {
        float: left;
        width: 25%;
        padding: 10px;
        font-size: 15px;
        line-height: 1.4;
        text-align: center;
        border: 1px solid #FFF;
        background-color: #e2e7ec;
    }
    .no-list li.success {
        background-color: green;
        color: white;
        font-weight: bold;
    }
    .no-list li.success > a {
        color: white;
    }
    .no-list li.ragu {
        background-color: #f89406;
        color: white;
        font-weight: bold;
    }
    .no-list li.ragu > a {
        color: white;
    }
    .nomor-navigasi ul.no-list {
        width: 130px;
        height: 700px;
        overflow: auto;
    }
    .nomor-navigasi.affix {
        margin-top: 5px;
    }
    .clock.affix {
        margin-top: -50px;
        margin-left: 60px;
    }
</style>
";
    }

    // line 60
    public function block_content($context, array $blocks = array())
    {
        // line 61
        echo "<div id=\"wrap\">
    <div class=\"container\">
        <div class=\"row-fluid\">
            <div class=\"span6\">
                <h1 class=\"title\">";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "judul"), "html", null, true);
        echo "</h1>
            </div>
            <div class=\"span6\">
                <ul class=\"unstyled inline pull-right user-info\">
                    <li><b>";
        // line 69
        echo twig_escape_filter($this->env, nama_panggilan(get_sess_data("user", "nama")), "html", null, true);
        echo "</b></li>
                    <li><img src=\"";
        // line 70
        echo twig_escape_filter($this->env, get_url_image_session(get_sess_data("user", "foto"), "medium", get_sess_data("user", "jenis_kelamin")), "html", null, true);
        echo "\" class=\"nav-avatar img-polaroid img-circle\" /></li>
                </ul>
            </div>
        </div>
        <hr class=\"hr-top\">
        <div class=\"wrap-content\">
            <div class=\"content\">
                <div class=\"row-fluid\">
                    ";
        // line 78
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") != 1)) {
            // line 79
            echo "                    <div class=\"span8\">
                        <b>Informasi : </b><br>
                        ";
            // line 81
            echo $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "info");
            echo "
                    </div>
                    <div class=\"span4\">
                        <div class=\"pull-right clock\" data-spy=\"affix\" data-offset-top=\"60\" data-offset-bottom=\"200\">
                            <div class=\"box-show-hide-countdown\">
                                ";
            // line 86
            $context["hide_countdown"] = sess_hide_countdown("get", $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"));
            // line 87
            echo "                                ";
            if (((isset($context["hide_countdown"]) ? $context["hide_countdown"] : null) == 1)) {
                // line 88
                echo "                                    <a href=\"javascript:void(0)\" onclick=\"show_countdown()\" class=\"text-muted\"><i class=\"icon icon-eye-open\"></i> TAMPILKAN TIMER</a>
                                ";
            } else {
                // line 90
                echo "                                    <a href=\"javascript:void(0)\" onclick=\"hide_countdown()\" class=\"text-muted\"><i class=\"icon icon-eye-close\"></i> SEMBUNYIKAN TIMER</a>
                                ";
            }
            // line 92
            echo "                            </div>
                            <div class=\"iosl-theme-wrapper countdown\" ";
            // line 93
            echo ((((isset($context["hide_countdown"]) ? $context["hide_countdown"] : null) == 1)) ? ("style=\"display:none;\"") : (""));
            echo ">
                                <div class=\"iosl-theme\">
                                    <ul>
                                        <li><p><span><em><b class=\"hours\">00</b><i class=\"hoursSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                        <li><p><span><em><b class=\"minutes\">00</b><i class=\"minutesSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                        <li><p><span><em><b class=\"seconds\">00</b><i class=\"secondsSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                    </ul>
                                    <div class=\"jC-clear\"></div>
                                    <p class=\"jCtext\">
                                        <span><em class=\"textSeconds\">SECONDS</em></span>
                                        <span><em class=\"textMinutes\">MINUTES</em></span>
                                        <span><em class=\"textHours\">HOURS</em></span>
                                    </p>
                                    <div class=\"jC-clear\"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
        } else {
            // line 112
            echo "                    <div class=\"span6\">
                        <p><b>Upload file tugas anda : </b></p>
                        <div class=\"well well-sm\">
                            ";
            // line 115
            echo form_open_multipart(((("tugas/submit_upload/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id")));
            echo "
                            <input type=\"file\" name=\"userfile\">
                            <hr class=\"hr1\">
                            <div class=\"row-fluid\">
                                <div class=\"span3\">
                                    <button type=\"submit\" class=\"btn btn-primary\">Upload</button>
                                </div>
                                <div class=\"span9\">
                                    ";
            // line 123
            echo get_flashdata("upload");
            echo "
                                </div>
                            </div>
                            ";
            // line 126
            echo form_close();
            echo "
                        </div>
                    </div>
                    <div class=\"span6\">
                        <b>Informasi Tugas : </b><br>
                        ";
            // line 131
            echo $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "info");
            echo "
                    </div>
                    ";
        }
        // line 134
        echo "                </div>

                ";
        // line 136
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") == 3)) {
            // line 137
            echo "                    <div class=\"row-fluid\">
                        <div class=\"span10\">
                            <table class=\"table datatable\">
                                <thead>
                                    <tr>
                                        <th style=\"width:40px;\">No</th>
                                        <th>Pertanyaan dan Pilihan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
            // line 147
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan"));
            foreach ($context['_seq'] as $context["no"] => $context["p"]) {
                // line 148
                echo "                                    <tr id=\"pertanyaan-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                        <td><b>";
                // line 149
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo ".</b></td>
                                        <td>
                                            <div class=\"pertanyaan\">
                                                ";
                // line 152
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
                echo "
                                            </div>

                                            <div id=\"pilihan-";
                // line 155
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                                <table class=\"table table-condensed table-striped\">
                                                    <tbody>
                                                        ";
                // line 158
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                    if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                        // line 159
                        echo "                                                        <tr>
                                                            <td style=\"width:30px;\"><label class=\"label-radio\"><input ";
                        // line 160
                        echo ((is_pilih($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "id"))) ? ("checked") : (""));
                        echo " type=\"radio\" name=\"pilihan-";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan"), "html", null, true);
                        echo "\" onclick=\"update_ganda_custom(";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "id"), "html", null, true);
                        echo ")\" class=\"radio\"> ";
                        echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index")), "html", null, true);
                        echo "</label></td>
                                                            <td>
                                                                ";
                        // line 162
                        echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                        echo "
                                                            </td>
                                                        </tr>
                                                        ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 166
                echo "
                                                        ";
                // line 167
                if ((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array")))) {
                    // line 168
                    echo "                                                        <tr id=\"ragu-";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                    echo "\" class=\"warning\">
                                                            <td colspan=\"2\">
                                                                <label class=\"checkbox\">
                                                                    <input type=\"checkbox\" name=\"ragu\" onclick=\"update_ragu(this.checked, ";
                    // line 171
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                    echo ")\" ";
                    echo ((((!twig_test_empty($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu"))) && in_array($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu")))) ? ("checked") : (""));
                    echo "> <b>Masih ragu-ragu</b>
                                                                </label>
                                                            </td>
                                                        </tr>
                                                        ";
                }
                // line 176
                echo "                                                    </tbody>
                                                </table>
                                            </div>

                                        </td>
                                    </tr>

                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 184
            echo "                                </tbody>
                            </table>

                            ";
            // line 187
            echo (isset($context["pagination"]) ? $context["pagination"] : null);
            echo "

                            ";
            // line 189
            if (((isset($context["tampil_btn_submit"]) ? $context["tampil_btn_submit"] : null) == 1)) {
                // line 190
                echo "                            <div class=\"well well-sm\">
                                <p class=\"p-info\">Periksa kembali jawaban anda sebelum mengahiri pengerjaan tugas ini.</p>
                                <button type=\"button\" class=\"btn btn-large btn-primary\" data-toggle=\"modal\" data-target=\"#selesai-mengerjakan\">
                                    Selesai Mengerjakan
                                </button>
                            </div>
                            ";
            }
            // line 197
            echo "
                            <div class=\"modal fade\" id=\"selesai-mengerjakan\" tabindex=\"-1\" role=\"dialog\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-body\">
                                            Anda yakin ingin mengahiri pengerjaan tugas ini?
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Nanti dulu</button>
                                            <a class=\"btn btn-primary\" href=\"";
            // line 206
            echo twig_escape_filter($this->env, site_url(((("tugas/finish/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id"))), "html", null, true);
            echo "\" id=\"btn-submit\">Ya, saya sudah selesai</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"span2\">
                            <div class=\"nomor-navigasi\">
                                <ul class=\"no-list\">
                                    ";
            // line 215
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan_id"));
            foreach ($context['_seq'] as $context["no"] => $context["p_id"]) {
                // line 216
                echo "                                        ";
                $context["no_class"] = "";
                // line 217
                echo "                                        ";
                if (((!twig_test_empty($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu"))) && in_array((isset($context["p_id"]) ? $context["p_id"] : null), $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu")))) {
                    // line 218
                    echo "                                            ";
                    $context["no_class"] = "ragu";
                    // line 219
                    echo "                                        ";
                } elseif ((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), (isset($context["p_id"]) ? $context["p_id"] : null), array(), "array")))) {
                    // line 220
                    echo "                                            ";
                    $context["no_class"] = "success";
                    // line 221
                    echo "                                        ";
                }
                // line 222
                echo "                                        <li id=\"no-pertanyaan-";
                echo twig_escape_filter($this->env, (isset($context["p_id"]) ? $context["p_id"] : null), "html", null, true);
                echo "\" class=\"";
                echo twig_escape_filter($this->env, (isset($context["no_class"]) ? $context["no_class"] : null), "html", null, true);
                echo "\"><a href=\"";
                echo twig_escape_filter($this->env, site_url(((((("plugins/custom_tugas/kerjakan/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["halaman"]) ? $context["halaman"] : null), (isset($context["p_id"]) ? $context["p_id"] : null), array(), "array")) . "#pertanyaan-") . (isset($context["p_id"]) ? $context["p_id"] : null))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo "</a></li>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p_id'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 224
            echo "                                </ul>
                            </div>
                        </div>
                    </div>

                ";
        }
        // line 230
        echo "

                ";
        // line 232
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") == 2)) {
            // line 233
            echo "                    ";
            echo form_open(((("plugins/custom_tugas/submit_essay/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id")), array("id" => "form-essay"));
            echo "
                    <input type=\"hidden\" id=\"str_id\" value=\"";
            // line 234
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "str_id"), "html", null, true);
            echo "\">
                    <table class=\"table datatable\">
                        <thead>
                            <tr>
                                <th width=\"5%\">No</th>
                                <th>Pertanyaan</th>
                            </tr>
                        </thead>
                        <tbody>
                            ";
            // line 243
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan"));
            foreach ($context['_seq'] as $context["no"] => $context["p"]) {
                // line 244
                echo "                            <tr id=\"pertanyaan-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                <td><b>";
                // line 245
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo ".</b></td>
                                <td>
                                    <div class=\"pertanyaan\">
                                        ";
                // line 248
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
                echo "
                                    </div>

                                    <textarea name=\"jawaban[";
                // line 251
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "]\" id=\"jawaban-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\" class=\"texteditor\">";
                echo get_jawaban($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"));
                echo "</textarea>

                                </td>
                            </tr>

                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 257
            echo "                        </tbody>
                    </table>

                    ";
            // line 260
            echo (isset($context["pagination"]) ? $context["pagination"] : null);
            echo "

                    <div id=\"info-ajax-href\"></div>

                    ";
            // line 264
            if (((isset($context["tampil_btn_submit"]) ? $context["tampil_btn_submit"] : null) == 1)) {
                // line 265
                echo "                    <div class=\"well well-sm\">
                        <p class=\"p-info\">Periksa kembali jawaban anda sebelum mengahiri pengerjaan tugas ini.</p>
                        <button type=\"button\" class=\"btn btn-large btn-primary\" data-toggle=\"modal\" data-target=\"#selesai-mengerjakan\">
                            Selesai Mengerjakan
                        </button>
                    </div>
                    ";
            }
            // line 272
            echo "
                    ";
            // line 273
            echo form_close();
            echo "

                    <div class=\"modal fade\" id=\"selesai-mengerjakan\" tabindex=\"-1\" role=\"dialog\">
                        <div class=\"modal-dialog\" role=\"document\">
                            <div class=\"modal-content\">
                                <div class=\"modal-body\">
                                    Anda yakin ingin mengahiri pengerjaan tugas ini?
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Nanti dulu</button>
                                    <button type=\"button\" class=\"btn btn-primary\" id=\"btn-submit\">Ya, saya sudah selesai</button>
                                </div>
                            </div>
                        </div>
                    </div>

                ";
        }
        // line 290
        echo "
            </div>
        </div>
    </div>
</div>
";
        // line 295
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") != 1)) {
            // line 296
            echo "<input type=\"hidden\" id=\"process-submit\" value=\"0\">
<input type=\"hidden\" id=\"tugas_id\" value=\"";
            // line 297
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"type_id\" value=\"";
            // line 298
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"sisa_menit\" value=\"";
            // line 299
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "sisa_menit"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"finish_url\" value=\"";
            // line 300
            echo twig_escape_filter($this->env, site_url(((("plugins/custom_tugas/finish/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id"))), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"siswa_id\" value=\"";
            // line 301
            echo twig_escape_filter($this->env, get_sess_data("user", "id"), "html", null, true);
            echo "\">
";
        }
    }

    public function getTemplateName()
    {
        return "ujian-online.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  567 => 301,  563 => 300,  559 => 299,  555 => 298,  551 => 297,  548 => 296,  546 => 295,  539 => 290,  519 => 273,  516 => 272,  507 => 265,  505 => 264,  498 => 260,  493 => 257,  477 => 251,  471 => 248,  465 => 245,  460 => 244,  456 => 243,  444 => 234,  439 => 233,  437 => 232,  433 => 230,  425 => 224,  410 => 222,  407 => 221,  404 => 220,  401 => 219,  398 => 218,  395 => 217,  392 => 216,  388 => 215,  376 => 206,  365 => 197,  356 => 190,  354 => 189,  349 => 187,  344 => 184,  331 => 176,  319 => 171,  312 => 168,  310 => 167,  307 => 166,  293 => 162,  276 => 160,  273 => 159,  262 => 158,  256 => 155,  250 => 152,  244 => 149,  239 => 148,  235 => 147,  223 => 137,  221 => 136,  217 => 134,  211 => 131,  203 => 126,  197 => 123,  186 => 115,  181 => 112,  159 => 93,  156 => 92,  152 => 90,  148 => 88,  145 => 87,  143 => 86,  135 => 81,  131 => 79,  129 => 78,  118 => 70,  114 => 69,  107 => 65,  101 => 61,  98 => 60,  44 => 8,  41 => 7,  33 => 4,  30 => 3,);
    }
}
