<?php

/* login_bayar.html */
class __TwigTemplate_6f8468f5eec973872041d40a552b2bd1f4745151a372256c37b1dd026e68f091 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-public.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-public.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Login - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"row\">
    ";
        // line 9
        if ((!twig_test_empty((isset($context["sliders"]) ? $context["sliders"] : null)))) {
            // line 10
            echo "    <div class=\"span5 offset1\">
          <div class=\"slider-wrapper theme-light\">
            <div id=\"slider-login\" class=\"nivoSlider\">
                ";
            // line 13
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sliders"]) ? $context["sliders"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 14
                echo "                <img src=\"";
                echo twig_escape_filter($this->env, get_url_image($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "value")), "html", null, true);
                echo "\" data-thumb=\"";
                echo twig_escape_filter($this->env, get_url_image($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "value")), "html", null, true);
                echo "\" title=\"#html";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "id"), "html", null, true);
                echo "\">
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 16
            echo "            </div>
            ";
            // line 17
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sliders"]) ? $context["sliders"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 18
                echo "            <div id=\"html";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "id"), "html", null, true);
                echo "\" class=\"nivo-html-caption\">
                ";
                // line 19
                echo $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "title");
                echo "
            </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 22
            echo "        </div>
    </div>
    ";
        }
        // line 25
        echo "
    <div class=\"module span4 ";
        // line 26
        echo ((twig_test_empty((isset($context["sliders"]) ? $context["sliders"] : null))) ? ("offset4") : (""));
        echo "\">
      <center> <H1>SISTEM SEDANG MAINTANCE</H1> </center>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "login_bayar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 26,  95 => 25,  90 => 22,  81 => 19,  76 => 18,  72 => 17,  69 => 16,  56 => 14,  52 => 13,  47 => 10,  45 => 9,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
